# Upstream Updates Report
**Generated:** 2025-11-15 02:51:06 UTC

## Summary

### NPM Packages

**Status:** 🟡 13 packages have updates available

| Package | Current | Latest | Type |
|---------|---------|--------|------|
| @anthropic-ai/sdk | 0.65.0 | 0.69.0 | major |
| @types/jest | 29.5.14 | 30.0.0 | major |
| @types/node | 20.19.25 | 24.10.1 | major |
| @typescript-eslint/eslint-plugin | 6.21.0 | 8.46.4 | major |
| @typescript-eslint/parser | 6.21.0 | 8.46.4 | major |
| 0x | 5.8.0 | 6.0.0 | major |
| better-sqlite3 | 11.10.0 | 12.4.1 | major |
| claude-flow | null | 2.7.31 | minor |
| dotenv | 16.6.1 | 17.2.3 | major |
| eslint | 8.57.1 | 9.39.1 | major |
| jest | 29.7.0 | 30.2.0 | major |
| lucide-react | 0.548.0 | 0.553.0 | major |
| zod | 3.25.76 | 4.1.12 | major |

**Action:** Run `npm update` for minor/patch, `npm install <pkg>@latest` for major

### Git Repositories

**Status:** ✅ Up to date with upstream

### Security Vulnerabilities

**Status:** 🟡 Vulnerabilities detected - run `npm audit` for details

### GitHub Actions

**Status:** ℹ️ 13 actions found (manual review recommended)

-         uses: actions/checkout@v4 (in test-agentdb.yml)
-         uses: actions/setup-node@v4 (in test-agentdb.yml)
-         uses: actions/upload-artifact@v4 (in test-agentdb.yml)
-         uses: actions/upload-artifact@v4 (in test-agentdb.yml)
-         uses: actions/checkout@v4 (in test-agentdb.yml)
-         uses: actions/setup-node@v4 (in test-agentdb.yml)
-         uses: actions/github-script@v7 (in test-agentdb.yml)
-         uses: actions/checkout@v4 (in test-agentdb.yml)
-         uses: actions/setup-node@v4 (in test-agentdb.yml)
-         uses: actions/checkout@v4 (in test-agentdb.yml)
-         uses: actions/setup-node@v4 (in test-agentdb.yml)
-         uses: actions/checkout@v4 (in test-agentdb.yml)
-         uses: actions/setup-node@v4 (in test-agentdb.yml)

**Action:** Check latest versions at https://github.com/<org>/<repo>/releases

## Recommendations

1. Review all 🔴 critical and 🟡 high-priority updates immediately
2. Schedule maintenance window for major version upgrades
3. Test updates in development/staging before production
4. Subscribe to security advisories for critical dependencies

---
*Next check: 2025-11-15*
